# Connecting the site to Google Sheets

This connects `register.html` and `store.html` to a Google Sheet, using a free
Google Apps Script "web app" as the bridge. No paid tools or extra accounts
needed — just your regular Google account.

Total time: about 10 minutes.

## 1. Create the Google Sheet

1. Go to [sheets.google.com](https://sheets.google.com) and create a new,
   blank spreadsheet.
2. Name it something like **ABC Conference — Responses**.
3. Leave it empty — the script will create the "Registrations" and "Orders"
   tabs automatically the first time someone submits a form.

## 2. Add the script

1. In the Sheet, click **Extensions → Apps Script**.
2. Delete any placeholder code in the editor.
3. Open the `Code.gs` file included with this site, copy all of it, and
   paste it into the Apps Script editor.
4. Click the **Save** icon (or press Ctrl/Cmd+S). Name the project
   "ABC Conference backend" if it asks.

## 3. Deploy it as a web app

1. In the Apps Script editor, click **Deploy → New deployment**.
2. Click the gear icon next to "Select type" and choose **Web app**.
3. Fill in:
   - **Description:** ABC Conference form handler
   - **Execute as:** Me (your account)
   - **Who has access:** Anyone
4. Click **Deploy**.
5. Google will ask you to authorize the script — click **Authorize access**,
   choose your Google account, and click **Allow** (you may need to click
   "Advanced" → "Go to ABC Conference backend (unsafe)" — this warning
   appears for all personal Apps Script projects, it's expected).
6. After deploying, copy the **Web app URL** shown. It looks like:
   `https://script.google.com/macros/s/AKfycb.../exec`

## 4. Paste the URL into the site

1. Open `script.js` in a text editor.
2. Find this line near the top:
   ```js
   const SHEET_WEBHOOK_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_URL_HERE";
   ```
3. Replace the placeholder text with the URL you copied, keeping the quotes:
   ```js
   const SHEET_WEBHOOK_URL = "https://script.google.com/macros/s/AKfycb.../exec";
   ```
4. Save the file.

## 5. Test it

1. Open `register.html` in a browser (double-click the file, or host the
   site — see below).
2. Fill out the form and submit it.
3. Check your Google Sheet — a new "Registrations" tab should appear with
   your test submission as the first row.
4. Do the same for `store.html` and check the "Orders" tab.

If nothing shows up, double check the URL in `script.js` doesn't have a
typo, and that you chose "Anyone" for access in step 3.

## 6. Re-deploying after changes

If you ever edit `Code.gs`, you need to create a **new deployment** (or
edit the existing one via **Deploy → Manage deployments → pencil icon →
New version**) for the changes to take effect. Editing the file alone does
not update the live web app.

## Hosting the site itself

This is a set of plain HTML/CSS/JS files — no build step required. You can
host it for free on any of these:

- **GitHub Pages** — push the folder to a GitHub repo, enable Pages in
  the repo settings.
- **Netlify / Vercel** — drag-and-drop the folder into their web dashboard.
- **Google Sites / your own web host** — upload the files via FTP or their
  file manager.

Whichever you choose, keep all the files (`index.html`, `register.html`,
`agenda.html`, `store.html`, `rules.html`, `style.css`, `script.js`) in the
same folder, since the pages link to each other by relative filename.
