/**
 * ABC CONFERENCE — Google Apps Script backend
 * -------------------------------------------
 * Receives form submissions from register.html and store.html and
 * appends each one as a new row in the bound Google Sheet, on a
 * tab named after the form type ("Registrations" or "Orders").
 *
 * Setup instructions are in SETUP-GOOGLE-SHEETS.md.
 */

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var formType = data.formType || "unknown";

    if (formType === "registration") {
      appendRegistration(data);
    } else if (formType === "store-order") {
      appendOrder(data);
    } else {
      appendGeneric(data);
    }

    return ContentService
      .createTextOutput(JSON.stringify({ result: "success" }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ result: "error", message: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function appendRegistration(data) {
  var sheet = getOrCreateSheet("Registrations", [
    "Submitted at", "Full name", "Email", "Organization", "Phone",
    "Arrival day", "Needs transport", "Transport notes",
    "Dietary/accessibility notes", "Agreed to rules", "Agreed to pay fee"
  ]);
  sheet.appendRow([
    data.submittedAt || new Date().toISOString(),
    data.fullName || "",
    data.email || "",
    data.organization || "",
    data.phone || "",
    data.arrivalDay || "",
    data.needsTransport || "",
    data.transportNotes || "",
    data.notes || "",
    data.agreeRules ? "Yes" : "No",
    data.agreeFee ? "Yes" : "No"
  ]);
}

function appendOrder(data) {
  var sheet = getOrCreateSheet("Orders", [
    "Submitted at", "Full name", "Email", "Items", "Notes"
  ]);
  sheet.appendRow([
    data.submittedAt || new Date().toISOString(),
    data.fullName || "",
    data.email || "",
    data.items || "",
    data.notes || ""
  ]);
}

function appendGeneric(data) {
  var sheet = getOrCreateSheet("Other submissions", ["Submitted at", "Raw data"]);
  sheet.appendRow([data.submittedAt || new Date().toISOString(), JSON.stringify(data)]);
}

function getOrCreateSheet(name, headerRow) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.appendRow(headerRow);
    sheet.setFrozenRows(1);
  }
  return sheet;
}
